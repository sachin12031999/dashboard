import Cards from "../components/Cards";

const Home = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <Cards />
          </div>
          <div className="col-md-4">
            <Cards />
          </div>
          <div className="col-md-4">
            <Cards />
          </div>
          <div className="col-md-4">
            <Cards />
          </div>
          <div className="col-md-4">
            <Cards />
          </div>
          <div className="col-md-4">
            <Cards />
          </div>
          <div className="col-md-4">
            <Cards />
          </div>
          <div className="col-md-4">
            <Cards />
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
